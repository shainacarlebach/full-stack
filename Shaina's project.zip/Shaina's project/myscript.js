function validateForm(myForm)
  {
    // regular expression to match required date format
    reDate = /^\d{1,2}\/\d{1,2}\/\d{4}$/;

    if(myForm.date.value != '' && !myForm.date.value.match(reDate)) {
      alert("Invalid date format: " + myForm.date.value);
      myForm.date.focus();
      return false;
    }

    // regular expression to match required time format
    reTime = /^\d{1,2}:\d{2}([ap]m)?$/;

    if(myForm.starttime.value != '' && !myForm.starttime.value.match(reTime)) {
      alert("Invalid time format: " + myForm.starttime.value);
      myForm.starttime.focus();
      return false;
    }
    // validation fails if the input is blank
    if(myForm.textarea.value == "") {
      alert("Error: Input is empty!");
      myForm.textarea.focus();
      return false;
    }

    // regular expression to match only alphanumeric characters and spaces
    var reText = /^[A-Za-z0-9]+$/;
  

    // validation fails if the input doesn't match our regular expression
    if(!reText.test(myForm.textarea.value)) {
      alert("Error: Input contains invalid characters!");
      myForm.textarea.focus();
      return false;
    }

    // validation was successful
    return true;
  }
   
var taskArray = [];

function loadTasks() {
    var stringFromStorage = localStorage.getItem("myTaskArray");
    taskArray = JSON.parse(stringFromStorage);
    for (var x = 0; x < taskArray.length; x++) {
        var note = taskArray[x];
        createYellowNote(note, x);
    }
}
//create Yellow Note to put in tasks from array

function createYellowNote(data, number) {

    var myTask = data["textarea"];
    var myDate = data["date"];
    var myTime = data["starttime"];

    var TaskNoteDiv = document.createElement("div");
    TaskNoteDiv.setAttribute("class", "TaskNoteDivClass");
    TaskNoteDiv.setAttribute("id", number);

    var TaskNoteTextArea = document.createElement("div");
    TaskNoteTextArea.setAttribute("class", "TaskNoteTextArea");

    TaskNoteTextArea.innerHTML = myTask;

    var TaskNoteDate = document.createElement("div");
    TaskNoteDate.setAttribute("class", "TaskNoteDate");

    TaskNoteDate.innerHTML = myDate;

    // Put remove glyphicon on to the TaskNoteDiv
    var span = document.createElement("span");
    span.setAttribute("class", "glyphicon glyphicon-remove");

    span.addEventListener("click", DeleteTask);

    TaskNoteDiv.appendChild(span);
    TaskNoteDiv.appendChild(TaskNoteTextArea);
    TaskNoteDiv.appendChild(TaskNoteDate);
    document.getElementById("notes").appendChild(TaskNoteDiv);
}

function saveTasktoStorage() {

    var myDate = document.getElementById("myDate").value;
    var myTime = document.getElementById("myTime").value;
    var myTask = document.getElementById("myTask").value;

    var toDoObject = { date: myDate, starttime: myTime, textarea: myTask };
    taskArray.push(toDoObject);
    var myJSON = JSON.stringify(taskArray);
    localStorage.setItem("myTaskArray", myJSON);
    var index = (taskArray.length - 1);

    createYellowNote(toDoObject, index);
}

function DeleteTask() {
    var myRemove = this.parentElement.getAttribute("id");
    document.getElementById(myRemove).remove();
    taskArray.splice(myRemove, 1);
    var myJSON = JSON.stringify(taskArray);
    localStorage.setItem("myTaskArray", myJSON);
}

